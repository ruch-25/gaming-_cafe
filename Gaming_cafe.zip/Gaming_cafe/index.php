<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  
error_reporting(0);  
session_start(); 

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Home || Gaming Cafe </title>

    <style>
        /* Add your custom CSS styles here */
        .login-button {
    position: relative;
    top: -120px;
    right: -550px;
    background-color: #28a745; /* Green color, you can change it */
    color: #fff;
    padding: 8px 15px;
    border-radius: 5px;
    text-decoration: none;
}

        body {
        font-family: 'Arial', sans-serif;
        background-image: url('images/photo/back.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        color: #333;
        margin: 0;
        padding: 0;
    }

        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #A569BD;
            color: #ABEBC6;
            padding: 10px;
            text-align: center;
        }

        .large-banner {
            background-color: #3498DB; /* Light Orange */
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }

        .featured-clay {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .featured-clay div {
            flex: 0 0 30%;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
        }

        .featured-clay div:hover {
            background-color: #e7d29a; /* Light Orange */
            color: #333;
            transform: translate(0, -5px) scale(1.02);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        .featured-clay div::before {
            content: "";
            background-size: cover;
                background-color: white; /* Set the background color to white */

            background-position: center;
            background-repeat: repeat;
            position: absolute;
            top: -2px;
            right: -2px;
            bottom: -2px;
            left: -2px;
            opacity: 0.5;
            transition: opacity 0.3s ease;
            z-index: -1;
        }

        .featured-clay div:hover::before {
            opacity: 0.8;
        }

        .featured-clay h3 {
            color: #333;
        }

        .featured-clay a {
            display: block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        /* Add background images for each game */
        .featured-clay div:nth-child(1)::before {
            background-image: url('images/photo/dow');
        }

        .featured-clay div:nth-child(2)::before {
            background-image: url('path/to/tic-tac-toe-image.jpg');
        }

        .featured-clay div:nth-child(3)::before {
            background-image: url('path/to/brain-bowl-image.jpg');
        }
    </style>
</head>
<body class="home">

<div class="dashboard-river">
    <div class="dashboard-container">
        <div class="dashboard">

            <div class="ui-row-2">
                <div class="main-content">
                <div class="header">
            <div class="page-display">
                <h1>Home</h1>
                <h2>Explore Our Games</h2>
                <a href="login.php" class="login-button">Login</a>
            </div>
        </div>

                    </div>
                    <div class="large-banner">
                        <h2>Explore Our Gaming World</h2>
                    </div>
                    <hr>
                    <div class="featured-clay">
    <div class="game game-chess">
      <div class="logo"></div>
      <h3></h3>
      <div class="rules">
        <p>Chess Rules:</p>
        <ol>
          <li>Starting Position: The game starts with pieces arranged on an 8x8 chessboard.</li>
          <li>Objective: Checkmate your opponent's king by putting it in a position where it cannot escape capture.</li>
          <li>Piece Movement: Pawns, Rooks, Knights, Bishops, Queens, and Kings move in specific ways.</li>
        
        </ol>
      </div>
    </div>

    <div class="game game-tictac">
      <div class="logo"></div>
      <h3</h3>
      <div class="rules">
        <p>Tic-Tac-Toe Rules:</p>
        <ol>
          <li>Two players take turns marking a square in a 3x3 grid.</li>
          <li>The first player to get three of their marks in a row (horizontally, vertically, or diagonally) wins.</li>
          <li>If the grid is filled and no player has three in a row, the game is a draw.</li>
        </ol>
      </div>
    </div>

    <div class="game game-brainbowl">
      <div class="logo"></div>
      <h3></h3>
      <div class="rules">
        <p>Brain Bowl Rules:</p>
        <ol>
          <li>Answer a series of challenging questions from various categories.</li>
          <li>Score points for correct answers.</li>
          <li>The participant or team with the highest score at the end wins.</li>
        </ol>
      </div>
    </div>
  </div>
     

                    <section class="how-it-works">

                    </section>

                    <?php include "include/footer.php" ?>


                    <script src="js/jquery.min.js"></script>
                    <script src="js/tether.min.js"></script>
                    <script src="js/bootstrap.min.js"></script>
                    <script src="js/animsition.min.js"></script>
                    <script src="js/bootstrap-slider.min.js"></script>
                    <script src="js/jquery.isotope.min.js"></script>
                    <script src="js/headroom.js"></script>
                    <script src="js/foodpicky.min.js"></script>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
