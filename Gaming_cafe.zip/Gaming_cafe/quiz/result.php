<?php
// Include your database connection file here
include("../connection/connect.php");
error_reporting(0);
session_start();

// Retrieve the user's username from the session
$username = $_SESSION['username'];

// Retrieve and calculate the user's total score from the individual question scores
$totalScoreQuery = mysqli_query($db, "SELECT q1, q2, q3, q4, q5 FROM user_scores WHERE username = '$username'");
$totalScoreRow = mysqli_fetch_assoc($totalScoreQuery);
$totalScore = array_sum($totalScoreRow);

// Update the total score in the user_scores table
mysqli_query($db, "UPDATE user_scores SET score = $totalScore WHERE username = '$username'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Quiz Result</title>
    <!-- Add your head content here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            padding: 20px;
        }

        h1, h2, p {
            margin-bottom: 20px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin: 10px 0;
        }

        .button-container {
            display: flex;
            justify-content: center;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 10px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h1>Quiz Result</h1>
<p>You scored <?php echo $totalScore; ?> out of <?php echo $totalQuestions; ?> questions.</p>

<h2>Correct Answers:</h2>
<ul>
    <?php
    // Fetch the total number of questions
    $totalQuestionsQuery = mysqli_query($db, "SELECT COUNT(*) as total_questions FROM questions");
    $totalQuestionsRow = mysqli_fetch_assoc($totalQuestionsQuery);
    $totalQuestions = $totalQuestionsRow['total_questions'];

    for ($i = 1; $i <= $totalQuestions; $i++) {
        $correctAnswerQuery = mysqli_query($db, "SELECT answer FROM questions WHERE id = $i");
        $correctAnswerRow = mysqli_fetch_assoc($correctAnswerQuery);
        $correctAnswer = $correctAnswerRow['answer'];

        echo '<li>Question ' . $i . ': ' . $correctAnswer . '</li>';
    }
    ?>
</ul>

<div class="button-container">
    <button onclick="returnToHome()">Return to Home</button>
</div>

<script>
    function returnToHome() {
        // Redirect to the home page or perform any other action
        window.location.href = "../indexdash.php";
    }
</script>

</body>
</html>
