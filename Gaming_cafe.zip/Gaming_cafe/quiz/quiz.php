<?php
// Include your database connection file here
include("../connection/connect.php");
error_reporting(0);
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the selected answer
    $selectedAnswer = $_POST['answer'];

    // Retrieve the correct answer from the database
    $correctAnswerQuery = mysqli_query($db, "SELECT answer FROM questions WHERE id = {$_SESSION['currentQuestion']}");
    $correctAnswerRow = mysqli_fetch_assoc($correctAnswerQuery);
    $correctAnswer = $correctAnswerRow['answer'];

    // Check if the selected answer is correct
    $isCorrect = ($selectedAnswer === $correctAnswer) ? 1 : 0;

    // Update the corresponding column for the current question in the user_scores table
    $columnName = 'q' . $_SESSION['currentQuestion'];
    $username = $_SESSION['username']; // Assuming you have a user session
  
    if ($_SESSION['currentQuestion'] === 1) {
        // Create a new row for the user in the user_scores table
        mysqli_query($db, "INSERT INTO user_scores (username, $columnName) VALUES ('$username', $isCorrect)");
    } else {
        // Update the existing row for the user and the current question
        mysqli_query($db, "UPDATE user_scores SET $columnName = $isCorrect WHERE username = '$username'");
    }

    // Move to the next question
    $_SESSION['currentQuestion']++;

    // Check if all questions are answered
    $totalQuestionsQuery = mysqli_query($db, "SELECT COUNT(*) as total_questions FROM questions");
    $totalQuestionsRow = mysqli_fetch_assoc($totalQuestionsQuery);
    $totalQuestions = $totalQuestionsRow['total_questions'];

    if ($_SESSION['currentQuestion'] > $totalQuestions) {
        // Redirect to the result page or perform any other action
        header("Location: result.php");
        exit();
    }
} else {
    // Set the initial question when the form is not submitted
    $_SESSION['currentQuestion'] = 1;
    // Set the start time for the current question
    $_SESSION['questionStartTime'] = time();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your head content here -->
    <title>Quiz Game</title>
    <style>
        body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    margin: 0;
}

.quiz_box {
    max-width: 600px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

header {
    text-align: center;
    margin-bottom: 20px;
}

.title {
    font-size: 24px;
    font-weight: bold;
    color: #333;
}

#timer {
    font-size: 18px;
    color: #e74c3c; /* Red color for the timer */
    margin-bottom: 10px;
}

que_text {
    font-size: 18px;
    margin-bottom: 20px;
}

.option_list {
    display: flex;
    flex-direction: column;
}

.option {
    margin-bottom: 10px;
}

button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #45a049;
}

/* Add additional styles or modify as needed */

    </style>


    <script>
        // JavaScript for the timer
        function startTimer() {
            var timeLeft = 10; // 10 seconds for each question

            var timer = setInterval(function() {
                document.getElementById('timer').innerHTML = timeLeft + 's';

                if (timeLeft <= 0) {
                    clearInterval(timer);
                    // Submit the form when the time is up
                    document.getElementById('quizForm').submit();
                }

                timeLeft--;
            }, 1000);
        }

        // Start the timer when the page loads
        window.onload = startTimer;
    </script>
    <style>
        /* Your existing CSS styles */
    </style>
</head>

<body>

<!-- Display the current question -->
<div class="quiz_box">
    <header>
        <div class="title">Brain Bowl</div>
        <div id="timer"></div>
        <!-- Add your timer and time_line here if needed -->
    </header>
    <section>
        <form id="quizForm" method="post" action="">
            <div class="que_text">
                <?php
                // Display the current question from the database
                $questionQuery = mysqli_query($db, "SELECT * FROM questions WHERE id = {$_SESSION['currentQuestion']}");
                $questionRow = mysqli_fetch_assoc($questionQuery);
                echo $questionRow['question'];
                ?>
            </div>
            <div class="option_list">
                <?php
                // Display answer options for the current question
                $optionsQuery = mysqli_query($db, "SELECT * FROM options WHERE question_id = {$_SESSION['currentQuestion']}");
                while ($optionRow = mysqli_fetch_assoc($optionsQuery)) {
                    echo '<div class="option">
                            <input type="radio" name="answer" value="' . $optionRow['option_text'] . '">
                            ' . $optionRow['option_text'] . '
                          </div>';
                }
                ?>
            </div>
            <button type="submit">Submit Answer</button>
        </form>
    </section>

    <!-- Add your footer content here -->
</div>

</body>
</html>
