<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if (isset($_POST['submit'])) {
    if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['cpassword']) || empty($_POST['email'])) {
        $message = "All fields must be Required!";
    } else {
        $check_username = mysqli_query($db, "SELECT username FROM userRegistration where username = '" . $_POST['username'] . "' ");
        $check_email = mysqli_query($db, "SELECT email FROM userRegistration where email = '" . $_POST['email'] . "' ");

        if ($_POST['password'] != $_POST['cpassword']) {
            echo "<script>alert('Password not match');</script>";
        } elseif (strlen($_POST['password']) < 6) {
            echo "<script>alert('Password Must be >=6');</script>";
        } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('Invalid email address please type a valid email!');</script>";
        } elseif (mysqli_num_rows($check_username) > 0) {
            echo "<script>alert('Username Already exists!');</script>";
        } elseif (mysqli_num_rows($check_email) > 0) {
            echo "<script>alert('Email Already exists!');</script>";
        } else {
            $mql = "INSERT INTO userRegistration(username,password,email) VALUES('" . $_POST['username'] . "','" . md5($_POST['password']) . "','" . $_POST['email'] . "')";
            mysqli_query($db, $mql);

            // Set a JavaScript variable for success
            echo '<script>var registrationSuccess = true;</script>';

            header("refresh:0.1;url=login.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Registration</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div style=" background-image: url('images/photo/gif3.gif');">
        <div class="page-wrapper">
            <div class="container">
                <section class="contact-page inner-page">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-body">
                                        <form action="" method="post">
                                            <div class="row">
                                                <div class="form-group col-sm-12">
                                                    <label for="exampleInputEmail1">User-Name</label>
                                                    <input class="form-control" type="text" name="username" id="example-text-input">
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="exampleInputEmail1">Email Address</label>
                                                    <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="exampleInputPassword1">Password</label>
                                                    <div class="input-group">
                                                        <input type="password" class="form-control" name="password" id="exampleInputPassword1">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" type="button" id="showPasswordBtn">Show</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script>
document.addEventListener('DOMContentLoaded', function () {
    var passwordInput = document.getElementById('exampleInputPassword1');
    var showPasswordBtn = document.getElementById('showPasswordBtn');

    showPasswordBtn.addEventListener('click', function () {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
        } else {
            passwordInput.type = 'password';
        }
    });
});
</script>
                                                <div class="form-group col-sm-6">
                                                    <label for="exampleInputPassword1">Confirm password</label>
                                                    <input type="password" class="form-control" name="cpassword" id="exampleInputPassword2">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <p> <input type="submit" value="Register" name="submit" class="btn theme-btn"> </p>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php include "include/footer.php" ?>
            </div>
            <script src="js/jquery.min.js"></script>
            <script src="js/tether.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <script src="js/animsition.min.js"></script>
            <script src="js/bootstrap-slider.min.js"></script>
            <script src="js/jquery.isotope.min.js"></script>
            <script src="js/headroom.js"></script>
            <script src="js/foodpicky.min.js"></script>
        </div>
    </div>
    <!-- Display the success message using JavaScript -->
    <script>
        // Check if registration was successful and display the popup
        if (typeof registrationSuccess !== 'undefined' && registrationSuccess) {
            alert('User registered successfully!');
        }
    </script>
</body>

</html>
