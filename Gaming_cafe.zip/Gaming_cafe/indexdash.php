                        <!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();
if(isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    // Redirect to the login page if the username is not set
    header("Location: login.php");
    exit();
}
// Retrieve username from session


if (isset($_POST['submit'])) {
    $review = $_POST['reviewText'];
    $rating = $_POST['rate'];
 


    if ($review == "" || $rating == "" || $username == "") {
        $error = '<div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <strong>All fields must be filled!</strong>
                </div>';
    } else{     
        $sql = "INSERT INTO reviews(review,username) VALUES('" .$review. "','" .$username. "')";
        mysqli_query($db, $sql);
        move_uploaded_file($temp, $store);

        $success = '<div class="alert alert-success alert-dismissible fade show">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        New comment Added Successfully.
                    </div>';
                
    } 
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>indexdashs</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('images/photo/pattern.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .chat-box {
            width: 100px;
            margin: 20px auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .chat-header {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }

        .chat-messages {
            padding: 10px;
            height: 200px;
            overflow-y: scroll;
            background-color: #f2f2f2;
        }

        .user-message, .bot-message {
            margin: 10px;
            padding: 8px;
            border-radius: 5px;
            max-width: 70%;
        }

        .user-message {
            background-color: #007bff;
            color: white;
            align-self: flex-end;
        }

        .bot-message {
            background-color: #ddd;
            align-self: flex-start;
        }

        .chat-input {
            width: calc(100% - 20px);
            padding: 10px;
            box-sizing: border-box;
            border: none;
            border-top: 1px solid #ccc;
            background-color: #f2f2f2;
            color: #333;
        }

        .send-button {
            width: 40px;
            height: 40px;
            padding: 10px;
            box-sizing: border-box;
            border: none;
            border-top: 1px solid #ccc;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        
        .side-text-box {
            flex: 0 0 200px;
        }

        .container-with-border {
            border: 1px solid #000;
            padding: 20px;
            max-width: 1000px; /* Adjust the max-width as needed */
            width: 100%;
            margin: 10px ;
            background-color: #eee; /* Set your desired background color */

        }
       
        h2{

text-align: center;
}
/* .comments-box {
    max-width: 400px;
    width: 100%;
    border: 1px solid #ced4da;
    border-radius: 5px;
    overflow: hidden;
    margin-top: 20px;
    background-color: #fff;
    padding: 20px;
    margin: 0 auto; /* This will center the comments-box horizontally */
    text-align: center; /* This will center the text inside the comments-box */
} */
.indexdash-page {
    width: 40%;

    background-color: #f8f9fa;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    text-align: center;
    margin: 0 auto; /* This will center the indexdash-page horizontally */
    text-align: center; /* This will center the text inside the indexdash-page */

}

.row {
    margin: 0 auto; /* Center the content within the row */
}

h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}


.comments-header {
background-color: #007bff;
color: white;
padding: 10px;
text-align: center;
}

.comments-list {
padding: 10px;
overflow-y: scroll;
max-height: 100px;
}

.comment {
margin: 10px;
padding: 8px;
border-radius: 5px;
background-color: #ecf0f1;
}

textarea {
width: calc(100% - 20px);
padding: 10px;
text-align: center;
margin: 0 auto 20px;
box-sizing: border-box;
border: 1px solid #ccc;
border-radius: 5px;
resize: vertical;
font-size: 16px;
line-height: 1.6;
transition: border-color 0.3s ease;
}

textarea:hover,
textarea:focus {
border-color: #007bff;
}

.form-actions {
text-align: center;
}

.btn {
padding: 10px 20px;
background-color: #007bff;
color: #fff;
border: none;
cursor: pointer;
font-size: 16px;
transition: background-color 0.3s ease;
}

.btn:hover {
background-color: #0056b3;
}

        .star {
            font-size: 24px;
            color: #ffd700; /* Gold color for stars */
            cursor: pointer;
        }

        
        .form-actions {
            text-align: center;
        }

        

       

        h2 {
            text-align: center;
            color: #333; /* Heading color */
            margin-bottom: 20px;
        }


      
       

        header {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            text-align: center;
            margin: 20px 0;
        }

            .star-widget {
                text-align: center;
                margin: 0 auto;
                max-width: 400px; /* Adjust the max-width as needed */
                background-color: #fff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            /* Hide radio buttons */
            .star-widget input[type="radio"] {
                display: none;
            }

            .star-widget {
                text-align: left;
            }

            .star-widget label {
                font-size: 40px;
                color: #444;
                padding: 10px;
                float: right;
                transition: all 0.2s ease;
            }

        input:not(:checked)~label:hover,
        input:not(:checked)~label:hover~label {
            color: #fd4;
        }

        input:checked~label {
            color: #fd4;
        }

        input#rate-5:checked~label {
            color: #fe7;
            text-shadow: 0 0 20px #952;
        }

        .star-widget form header {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .textarea {
            margin-bottom: 20px;
        }

        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
            font-size: 16px;
            line-height: 1.6;
            transition: border-color 0.3s ease;
        }

        textarea:hover,
        textarea:focus {
            border-color: #007bff;
        }

        .btn {
            text-align: center;
        }

        button {
            padding: 12px 24px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        #rate-1:checked~form header:before {
            content: "I just hate it ";
        }

        #rate-2:checked~form header:before {
            content: "I don't like it ";
        }

        #rate-3:checked~form header:before {
            content: "It is awesome ";
        }

        #rate-4:checked~form header:before {
            content: "I just like it ";
        }

        #rate-5:checked~form header:before {
            content: "I just love it ";
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #A569BD;
            color: #ABEBC6;
            padding: 10px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex; /* Use flexbox to create a row layout */
            justify-content: space-between; /* Align items at the start and end */
        }

        .comments-box {
            flex: 1; /* Take remaining space */
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .reviews-section {
            flex: 1; /* Take remaining space */
            padding-left: 20px; /* Add space between the two sections */
        }

        .bg-gray {
            background-color: #eee;
            padding: 20px;
            border-radius: 8px;
        }

        .review-item {
            margin-bottom: 10px;
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 8px;
        }

        .large-banner {
            background-color: #3498DB; /* Light Orange */
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }
        .container-with-border {
            border: 2px solid #000;
            padding: 20px;
            max-width: 800px; /* Adjust the max-width as needed */
            margin: 20px auto;
        }

        .featured-clay {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .featured-clay div {
            flex: 0 0 30%;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
        }

        .featured-clay div:hover {
            background-color: #e7d29a; /* Light Orange */
            color: #333;
            transform: translate(0, -5px) scale(1.02);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        .featured-clay div::before {
            content: "";
            background-size: cover;
            background-position: center;
            background-repeat: repeat;
            position: absolute;
            top: -2px;
            right: -2px;
            bottom: -2px;
            left: -2px;
            opacity: 0.5;
            transition: opacity 0.3s ease;
            z-index: -1;
        }

        .featured-clay div:hover::before {
            opacity: 0.8;
        }

        .featured-clay h3 {
            color: #333;
        }

        .featured-clay a {
            display: block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        /* Add background images for each game */
        .featured-clay div:nth-child(1)::before {
            background-image: url('images/photo/dow');
        }

        .featured-clay div:nth-child(2)::before {
            background-image: url('path/to/tic-tac-toe-image.jpg');
        }

        .featured-clay div:nth-child(3)::before {
            background-image: url('path/to/brain-bowl-image.jpg');
        }
        /* Chat box styles */
        .chat-box1 {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .chat-box {
            width: 100%;
            border: 1px solid #333;
            border-radius: 5px;
            overflow: hidden;
            margin-top: 20px;
        }

        .chat-header {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: center;
        }

        .chat-messages {
            padding: 10px;
            overflow-y: scroll;
            max-height: 200px;
        }

        .user-message,
        .bot-message {
            margin: 10px;
            padding: 8px;
            border-radius: 5px;
        }

        .user-message {
            background-color: #2196F3;
            color: white;
            text-align: right;
        }

        .bot-message {
            background-color: #ddd;
            text-align: left;
        }

        .chat-input {
            width: calc(100% - 50px);
            padding: 10px;
            box-sizing: border-box;
            border: none;
            border-top: 1px solid #ccc;
            float: left;
        }

        .send-button {
            width: 50px;
            padding: 10px;
            box-sizing: border-box;
            border: none;
            border-top: 1px solid #ccc;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            float: right;
        }

        /* Review box styles */
        .review-box {
            width: 100%;
            border: 1px solid #333;
            border-radius: 5px;
            overflow: hidden;
            margin-top: 20px;
        }

        .review-header {
            background-color: #f39c12;
            color: white;
            padding: 10px;
            text-align: center;
        }

        .review-list {
            padding: 10px;
            overflow-y: scroll;
            max-height: 200px;
        }

        .review {
            margin: 10px;
            padding: 8px;
            border-radius: 5px;
            background-color: #ecf0f1;
        }
        h3{
            text-align: center;
            color: white;
            margin-bottom: 20px;

        }
        .logout-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: white;
            color: black;
            padding: 15px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-button:hover {
            background-color: #0056b3;
        }
    </style>

    </head>
<body>
<h3>Welcome, <?php echo $username; ?>!</h3>

<button class="logout-button" onclick="logout()">Logout</button>
        <!-- Rest of your code remains unchanged -->

        <script>
            // Existing scripts remain unchanged

            function logout() {
                // Add your logout logic here
                alert("Logging out!");
                // Redirect to logout page or perform other logout actions
                window.location.href = "logout.php";
            }
        </script>
 
       
        <div class="dashboard-container">
            <div class="dashboard">
                <div class="ui-row-2">
                    <div class="main-content">
                       
                        <div class="large-banner">
                            <h2>Explore Our Gaming World</h2>
                        </div>
                        <hr>
                        <div class="container-with-border">

                        <div class="featured-clay">
                            <div style="background-color: #7bb5e5;">
                                <div></div>
                                <div>
                                    <h3>Chess Game</h3>
                                    <a href="chess/chess.html" title="featured clay">Let's Go</a>
                                </div>
                            </div>
                            <div style="background-color: #f3af9d;">
                                <div></div>
                                <div>
                                    <h3>Tic-Toe Game</h3>
                                    <a href="tic-toe/tictac.html" title="featured clay">Let's Go</a>
                                </div>
                            </div>
                            <div style="background-color: #add8e6;">
                                <div></div>
                                <div>
                                    <h3>Brain Bowl Game</h3>
                                    <a href="quiz/quiz.php"  title="featured clay">Let's Go</a>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="container">
        <div class="comments-box">
            <div class="review-header">
                <h2>Leave a Review</h2>
            </div>
            <form action="#" method="POST">
                <div class="star-widget">
                    <input type="radio" name="rate" id="rate-5">
                    <label for="rate-5" class="star">&#9733;</label>
                    <input type="radio" name="rate" id="rate-4">
                    <label for="rate-4" class="star">&#9733;</label>
                    <input type="radio" name="rate" id="rate-3">
                    <label for="rate-3" class="star">&#9733;</label>
                    <input type="radio" name="rate" id="rate-2">
                    <label for="rate-2" class="star">&#9733;</label>
                    <input type="radio" name="rate" id="rate-1">
                    <label for="rate-1" class="star">&#9733;</label>
                </div>
                <div class="textarea">
                    <textarea cols="30" name="reviewText" placeholder="Describe your experience.."></textarea>
                </div>
                <div class="form-actions">
                    <input type="submit" name="submit" class="btn btn-primary" value="Save">
                </div>
            </form>
        </div>

        <div class="reviews-section">
            <section class="indexdash-page">
                <div class="bg-gray indexdash-entry">
                    <div class="row justify-content-center">
                        <h2>Recent Comments</h2>
                        <?php
                        $ress = mysqli_query($db, "SELECT * FROM reviews");
                        while ($rows = mysqli_fetch_array($ress)) {
                            echo "<div class='review-item'>";
                            echo "<strong>{$rows['username']}</strong>: {$rows['review']}";
                            echo "</div>";
                        }
                        ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="chat-box1">  
<div class="chat-box">
        <div class="chat-header">
            <h2>Chat Box <i class="fas fa-comment-alt"></i></h2>
        </div>
        <div class="chat-messages" id="chatMessages">
            <div class="user-message">Hello, how can I help you?</div>
            <div class="bot-message">I'm doing well, thank you!</div>
            <!-- Add more messages here -->
        </div>
        <div style="display: flex;">
            <input type="text" class="chat-input" id="userMessage" placeholder="Type your message...">
            <button class="send-button" onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>

        <script>
            function sendMessage() {
                var userMessage = document.getElementById("userMessage").value;
                if (userMessage.trim() !== "") {
                    var chatMessages = document.getElementById("chatMessages");
                    var newMessage = document.createElement("div");
                    newMessage.className = "user-message";
                    newMessage.textContent = userMessage;
                    chatMessages.appendChild(newMessage);
                    document.getElementById("userMessage").value = "";
                }
            }
        </script>
    </div>
</div>

    <!-- <?php include "include/footer.php" ?> -->

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>