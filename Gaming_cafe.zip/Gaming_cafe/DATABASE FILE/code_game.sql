-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 22, 2023 at 08:03 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `game cafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(11) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `registation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `registation_date`, `date`) VALUES
(1, 'ruchitha', '21232f297a57a5a743894a0e4a801fc3', '', '2023-02-22 07:18:13'),
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', '', '2023-02-22 07:18:13');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `userRegistration` (
   `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  
  `registation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dishes`
--

INSERT INTO `userRegistration` (`username`, `password`, `registation_date`) VALUES
('ruchitha', '1234', '2023-02-22 07:18:13'),
('admin', 'admin', '2023-02-22 07:18:13');
-- --------------------------------------------------------

--
-- Table structure for table `remark`
--
CREATE TABLE `reviews` (
  `slno` INT (11) AUTO_INCREMENT PRIMARY KEY,
  `review` VARCHAR(255) NOT NULL,
  `username` VARCHAR(255) NOT NULL,
  `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `reviews` (`slno`,`review`, `username`, `timestamp`) VALUES
('1','nys', 'ruchitha', '2023-02-22 07:18:13');
-- --------------------------------------------------------
CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT,
    answer VARCHAR(255)
);

-- Insert data into the questions table
INSERT INTO questions (question, answer) VALUES
('What does HTML stand for?', 'Hyper Text Markup Language'),
('What does CSS stand for?', 'Cascading Style Sheet'),
('What does PHP stand for?', 'Hypertext Preprocessor'),
('What does SQL stand for?', 'Structured Query Language'),
('What does XML stand for?', 'eXtensible Markup Language');

-- Create the options table
CREATE TABLE options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT,
    option_text VARCHAR(255),
    is_correct BOOLEAN,
    FOREIGN KEY (question_id) REFERENCES questions(id)
);

-- Insert options data
INSERT INTO options (question_id, option_text, is_correct) VALUES
(1, 'Hyper Text Preprocessor', FALSE),
(1, 'Hyper Text Markup Language', TRUE),
(1, 'Hyper Text Multiple Language', FALSE),
(1, 'Hyper Tool Multi Language', FALSE),

(2, 'Common Style Sheet', FALSE),
(2, 'Colorful Style Sheet', FALSE),
(2, 'Computer Style Sheet', FALSE),
(2, 'Cascading Style Sheet', TRUE),

(3, 'Hypertext Preprocessor', TRUE),
(3, 'Hypertext Programming', FALSE),
(3, 'Hypertext Preprogramming', FALSE),
(3, 'Hometext Preprocessor', FALSE),

(4, 'Stylish Question Language', FALSE),
(4, 'Stylesheet Query Language', FALSE),
(4, 'Statement Question Language', FALSE),
(4, 'Structured Query Language', TRUE),

(5, 'eXtensible Markup Language', TRUE),
(5, 'eXecutable Multiple Language', FALSE),
(5, 'eXTra Multi-Program Language', FALSE),
(5, 'eXamine Multiple Language', FALSE);

CREATE TABLE user_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    q1 INT DEFAULT 0,
    q2 INT DEFAULT 0,
    q3 INT DEFAULT 0,
    q4 INT DEFAULT 0,
    q5 INT DEFAULT 0,
    score INT DEFAULT 0
);


ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
--
ALTER TABLE `userRegistration`
  ADD PRIMARY KEY (`username`);

--
--


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
