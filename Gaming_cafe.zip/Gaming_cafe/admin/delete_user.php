<?php
include("../connection/connect.php");
error_reporting(0);

session_start();

// Attempt to delete the user
mysqli_query($db, "DELETE FROM userregistration WHERE username = '" . $_GET['res_del'] . "'");
move_uploaded_file($temp, $store);

$success = '<div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                User deleted successfully.
            </div>';
// JavaScript code to show alert
echo '<script type="text/javascript">
        alert("User deleted successfully!");
        window.location.href = "listUsers.php"; // Redirect after showing the alert
      </script>';
?>
