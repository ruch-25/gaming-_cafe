<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include("../connection/connect.php");
    error_reporting(0);
    session_start();
    if (isset($_POST['dummy'])) {
        header("Location: demo.php");
        exit();            }
    // Function to display an alert with the button name
    if (isset($_POST['addUser'])) {
        header("Location: addUser.php");
        exit();            }
    if (isset($_POST['listUsers'])) {
        header("Location: listUsers.php");
        exit();    }
    if (isset($_POST['deleteReview'])) {
        header("Location: review.php");
    }
    if (isset($_POST['addquestion'])) {
        header("Location: addquestion.php");
    }
    if (isset($_POST['deletequestion'])) {
        header("Location: deletequestion.php");
    }
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .quefeatured-clay {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
}

         .centered-body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 70vh;
            margin: 0;
        }

    .box {
        background-color: #f8f8f8;
        border: 1px solid #ddd;
        padding: 20px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .media {
        display: flex;
        align-items: center;
    }

    .media-left {
        margin-right: 15px;
    }

    .media i {
        color: #333;
    }

    .media-body h2 {
        font-size: 28px;
        margin-bottom: 5px;
        color: #333;
    }

    .media-body p {
        margin: 0;
        color: #888;
    }
    
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        
        }

        .main-content {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 15px;
            text-align: center;
            display: flex;
            justify-content: space-between;
        }

        .header h1, .header h2 {
            margin: 0;
        }

        .logout-btn {
            background-color: #3498db;
            color: #fff;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .large-banner {
            background-color: #3498DB; /* Light Orange */
            padding: 20px;
            margin: 10px;
            text-align: center;
        }

        form {
            text-align: center;
            margin-top: 10px;
        }

        .box {
            width: 200px;
            height: 300px;
            background-color: #3498db;
            margin: 10px;
            display: inline-block;
            cursor: pointer;
            transition: transform 0.3s ease-in-out;
        }

        .box i {
            font-size: 36px;
            color: #fff;
            line-height: 100px;
        }

        .box:hover {
            transform: scale(1.1);
        }

        .featured-clay {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .quefeatured-clay {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
/* Add User button */
.button-add-user {
    background-color: #28a745; /* Green color */
    color: #fff; /* White text color */
}

/* List User button */
.button-list-users {
    background-color: #007bff; /* Blue color */
    color: #fff; /* White text color */
}

/* List and Delete User button */
.button-delete-user {
    background-color: #dc3545; /* Red color */
    color: #fff; /* White text color */
}
.button-add-question {
    background-color: #28a745; /* Red color */
    color: #fff; /* White text color */
}
.button-delete-question {
    background-color: #dc3545; /* Red color */
    color: #fff; /* White text color */
}

        .featured-clay .game {
            flex: 0 0 calc(30% - 40px); /* Adjust the width and spacing as needed */
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
        }

        .featured-clay .game:hover {
            background-color: #e7d29a; /* Light Orange */
            color: #333;
            transform: translate(0, -5px) scale(1.02);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        .featured-clay .game::before {
            content: "";
            background-size: cover;
            background-position: center;
            background-repeat: repeat;
            position: absolute;
            top: -2px;
            right: -2px;
            bottom: -2px;
            left: -2px;
            opacity: 0.5;
            transition: opacity 0.3s ease;
            z-index: -1;
        }

        .featured-clay .game:hover::before {
            opacity: 0.8;
        }

        .featured-clay h3 {
            color: #333;
        }

        .featured-clay a {
            display: block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }


        .quefeatured-clay .game {
            flex: 0 0 calc(30% - 40px); /* Adjust the width and spacing as needed */
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
        }

        .quefeatured-clay .game:hover {
            background-color: #e7d29a; /* Light Orange */
            color: #333;
            transform: translate(0, -5px) scale(1.02);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        .quefeatured-clay .game::before {
            content: "";
            background-size: cover;
            background-position: center;
            background-repeat: repeat;
            position: absolute;
            top: -2px;
            right: -2px;
            bottom: -2px;
            left: -2px;
            opacity: 0.5;
            transition: opacity 0.3s ease;
            z-index: -1;
        }

        .quefeatured-clay .game:hover::before {
            opacity: 0.8;
        }

        .quefeatured-clay h3 {
            color: #333;
        }

        .quefeatured-clay a {
            display: block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        footer {
    background-color: #333; /* Set your desired background color */
    color: #fff; /* Set text color */
    padding: 10px 0;
    text-align: center;
}

    </style>
</head>
<body>
<div style=" background-image: url('../images/photo/back.jpg');">

<div class="main-content">
    <div class="header">
        <div class="page-display">
             <h1>Admin Dashboard</h1>
        </div>
                        <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                            <ul class="dropdown-user">
                                <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                            </ul>
                        </div>
    </div>

 
</div>
<div class="centered-body">
<div class="box">
    <div class="row">
    <div class="col-md-3">
    <div class="card p-30">
        <div class="media">
            <div class="media-left meida media-middle">
                <span><i class="fa fa-home f-s-40 "></i></span>
            </div>
            <div class="media-body media-text-right">
                <h2><?php 
                    $sql="SELECT * FROM userregistration";
                    $result=mysqli_query($db,$sql); 
                    $rws=mysqli_num_rows($result);
                    echo $rws;
                ?></h2>
                <p class="m-b-0">Users</p>
            </div>
        </div>
    </div>
</div>

<div class="col-md-3">
    <div class="card p-30">
        <div class="media">
            <div class="media-left meida media-middle">
                <span><i class="fa fa-cutlery f-s-40" aria-hidden="true"></i></span>
            </div>
            <div class="media-body media-text-right">
                <h2><?php 
                    $sql="SELECT * FROM reviews";
                    $result=mysqli_query($db,$sql); 
                    $rws=mysqli_num_rows($result);
                    echo $rws;
                ?></h2>
                <p class="m-b-0">Reviews</p>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
</div>
<form method="post">

    <div class="featured-clay">
        <div class="game game-chess">
            <div class="logo"></div>
            <h3>Add User</h3>
            <button class="box button-add-user" name="addUser" type="submit">
                <i class="fas fa-user-plus"></i>
            </button>
        </div>

        <div class="game game-tictac">
            <div class="logo"></div>
            <h3>List User</h3>
            <button class="box button-list-users" name="listUsers" type="submit">
                <i class="fas fa-list"></i>
            </button>
            <div class="rules"></div>
        </div>

        <div class="game game-brainbowl">
            <div class="logo"></div>
            <h3>List and delete Review</h3>
            <button class="box button-delete-user" name="deleteReview" type="submit">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    </div>

    <div class="quefeatured-clay">
        <div class="game game-chess">
            <div class="logo"></div>
            <h3>Add Questions</h3>
            <button class="box button-add-question" name="addquestion" type="submit">
                <i class="fas fa-user-plus"></i>
            </button>
        </div>

        <div class="game game-chess">
            <div class="logo"></div>
            <h3>Delete questions</h3>
            <button class="box button-delete-question" name="deletequestion" type="submit">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    </div>

</form>




<?php include "include/footer.php" ?>
</body>
</html>
