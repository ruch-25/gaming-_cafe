<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the delete button is clicked
    if (isset($_POST['deleteQuestion'])) {
        $deleteQuestionId = $_POST['deleteQuestionId'];

        // Delete options first
        $deleteOptionsQuery = "DELETE FROM options WHERE question_id = '$deleteQuestionId'";
        mysqli_query($db, $deleteOptionsQuery);

        // Delete the question
        $deleteQuestionQuery = "DELETE FROM questions WHERE id = '$deleteQuestionId'";
        mysqli_query($db, $deleteQuestionQuery);
    }
}

// Fetch and display questions
$fetchQuestionsQuery = "SELECT * FROM questions";
$result = mysqli_query($db, $fetchQuestionsQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Add your head content here -->
    <title>List Questions</title>
    <!-- Add your stylesheet link here -->
</head>
<style>

body {
    font-family: Arial, sans-serif;
    background-image: url('../images/photo/back.jpg');
    margin: 0;
    padding: 0;
}

.question-list {
    max-width: 600px;
    margin: 20px auto;
    background-color: #f4f4f4;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.question-list h2 {
    text-align: center;
    margin-bottom: 20px;
}

.question-list ul {
    list-style: none;
    padding: 0;
}

.question-list li {
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between; /* Align items in a row with space between them */
}

.question-list button {
    background-color: #4caf50;
    color: #fff;
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.question-list button:hover {
    background-color: #45a049;
}

/* Optional: Style for the "Exit" button */
button {
    background-color: #d9534f;
    color: #fff;
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin-top: 20px;
    float: right; /* Align to the right */
}

button:hover {
    background-color: #c9302c;
}

</style>

<body>
    <!-- Display the list of questions -->
    <div class="question-list">
        <h2>List of Questions</h2>
        <ul>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                $questionId = $row['id'];
                $questionText = $row['question'];
            ?>
                <li>
                    <span><?php echo $questionText; ?></span>
                    <form method="post" onsubmit="return confirm('Are you sure you want to delete this question?');">
                        <input type="hidden" name="deleteQuestionId" value="<?php echo $questionId; ?>">
                        <button type="submit" name="deleteQuestion">Delete</button>
                    </form>
                </li>
            <?php
            }
            ?>
        </ul>
    </div>
    <button type="button" onclick="window.location.href='adminindexdash.php';">Exit</button>

    <!-- Add your additional HTML content here -->

</body>

</html>
