<?php
include("../connection/connect.php");
error_reporting(0);

session_start();
echo "<script>alert('You clicked the deleteReview button!');</script>";


mysqli_query($db,"DELETE FROM reviews WHERE slno = '".$_GET['res_del']."'");
header("location:review.php");  

?>