<!DOCTYPE html>
<html lang="en">

<?php
include("../connection/connect.php");
error_reporting(0);
session_start();
if (isset($_POST['submit'])) {
    if (empty($_POST['name']) || $_POST['email'] == '' || $_POST['rgdt'] == '' || $_POST['password'] == '' || $_POST['cpassword'] == '') {
        $error = '<div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <strong>All fields must be filled!</strong>
                </div>';
    } elseif ($_POST['password'] == $_POST['cpassword']) {

        $name = $_POST['name'];
        $date = $_POST['rgdt'];
        $password = md5($_POST['password']);
        $sql = "INSERT INTO userregistration(username,email,password) VALUES('" . $name . "','" . $_POST['email'] . "','" . md5($password) . "')";
        mysqli_query($db, $sql);
        move_uploaded_file($temp, $store);

        $success = '<div class="alert alert-success alert-dismissible fade show">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        New User Added Successfully.
                    </div>';
        // JavaScript code to show alert
        echo '<script type="text/javascript">
                alert("New User Added Successfully!");
              </script>';
    } else {
        $error = '<div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <strong>Passwords do not match</strong>
                </div>';
    }
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Add User</title>
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/helper.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/photo/back.jpg');
        }

        .card-outline-primary {
            border: 1px solid #007bff;
        }

        .card-header {
            background-color: #007bff;
            color: #fff;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-actions {
            margin-top: 20px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-inverse {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-inverse:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>

<body class="fix-header">
    <div style="background-image: url('../images/photo/back.jpg');">
        <div id="main-wrapper">
            <div class="page-wrapper">
                <div class="container-fluid">
                    <?php echo $error;
                    echo $success; ?>
                    <div class="col-lg-12">
                        <div class="card card-outline-primary">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">Add User</h4>
                            </div>
                            <div class="card-body">
                                <form action='' method='post' enctype="multipart/form-data">
                                    <div class="form-body">
                                        <hr>
                                        <div class="row p-t-20">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">User Name</label>
                                                    <input type="text" name="name" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group has-danger">
                                                    <label class="control-label">User E-mail</label>
                                                    <input type="text" name="email" class="form-control form-control-danger">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Registration Date </label>
                                                    <input type="text" name="rgdt" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Password</label>
                                                    <div class="input-group">
                                                        <input type="password" name="password" class="form-control" id="password">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="togglePassword">&#128065;</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row p-t-20">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Confirm Password</label>
                                                    <div class="input-group">
                                                        <input type="password" name="cpassword" class="form-control" id="cpassword">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="toggleConfirmPassword">&#128065;</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <a href="adminindexdash.php" class="btn btn-inverse">Cancel</a>
                                        <input type="submit" name="submit" class="btn btn-primary" value="Save">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include "include/footer.php" ?>
            </div>
        </div>
    </div>
    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script>
        document.getElementById('togglePassword').addEventListener('click', function () {
            togglePasswordVisibility('password');
        });

        document.getElementById('toggleConfirmPassword').addEventListener('click', function () {
            togglePasswordVisibility('cpassword');
        });

        function togglePasswordVisibility(inputId) {
            var passwordInput = document.getElementById(inputId);
            var type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
        }
    </script>
</body>

</html>
