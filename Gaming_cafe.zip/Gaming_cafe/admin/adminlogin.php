
<!DOCTYPE html>
                <html lang="en">
                <?php
include("connection/connect.php");
error_reporting(0);
session_start();
if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(!empty($_POST["submit"])) 
     {
	$loginquery ="SELECT * FROM admin WHERE username='$username' && password='".md5($password)."'";
	$result=mysqli_query($db, $loginquery);
	$row=mysqli_fetch_array($result);
	
	                        if(is_array($row))
								{
                                    	$_SESSION["adm_id"] = $row['adm_id'];
                                        header("refresh:0.1;url=index.php");
                                    } 
							else
							    {
										echo "<script>alert('Invalid Username or Password!');</script>"; 
                                }
	 }
	
	
}

?>
      
                <head>
                    <meta charset="UTF-8">
                    <title>Admin Login</title>

                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
                    <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
                    <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
                    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

                    <link rel="stylesheet" href="admin/css/login.css">
                 <style>
                    body {
    background-color: #f1f1f1;
    font-family: 'Roboto', sans-serif;
}

.container {
    text-align: center;
    margin-top: 50px;
}

.info h1 {
    color: #333;
}

.form {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: grey;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.thumbnail img {
    width: 100px;
    border-radius: 50%;
}

.login-form input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

.login-form input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    cursor: pointer;
}

.login-form input[type="submit"]:hover {
    background-color: #45a049;
}

span {
    display: block;
    margin-top: 10px;
}

span.color-red {
    color: red;
}

span.color-green {
    color: green;
}
.thumbnail {
    text-align: center;
}

.thumbnail img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: 2px solid #3498db; /* You can change the color as needed */
}

.form {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: grey;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.info {
    text-align: center;
    margin-bottom: 20px;
}

.info h1 {
    color: #333;
    font-size: 24px;
    margin: 10px 0;
}


</style>

                </head>

                <body>
              <div class="container">
                        <div class="info">
                            <h1>Admin Panel </h1>
                        </div>
                    </div>
                    <div class="form">
                        <div class="thumbnail"><img src="images/manager.png" /></div>
                        <span style="color:red;"><?php echo $message; ?></span>
                        <span style="color:green;"><?php echo $success; ?></span>
                        <form class="login-form" action="index.php" method="post">
                            <input type="text" placeholder="Username" name="username" />
                            <input type="password" placeholder="Password" name="password" />
                            <input type="submit" name="submit" value="Login" />

                        </form>
                    </div>
                    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
                    <script src='js/index.js'></script>
                </body>

                </html>
