<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

// Initialize success message variable
$successMessage = "";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addQuestion'])) {
        // Process form to add a new question
        $newQuestion = $_POST['newQuestion'];
        $newAnswer = $_POST['newAnswer'];

        // Insert the new question into the database
        $insertQuestionQuery = "INSERT INTO questions (question, answer) VALUES ('$newQuestion', '$newAnswer')";

        mysqli_query($db, $insertQuestionQuery);


        // Get the newly inserted question ID
        $newQuestionId = mysqli_insert_id($db);

        // Insert options into the options table
        for ($i = 1; $i <= 4; $i++) {
            $optionText = $_POST["option$i"];
            $isCorrect = ($i == $_POST['correctOption']) ? 1 : 0;

            $insertOptionQuery = "INSERT INTO options (question_id, option_text, is_correct) VALUES ('$newQuestionId', '$optionText', '$isCorrect')";
            mysqli_query($db, $insertOptionQuery);
        }
 $updateUserScoresQuery = "ALTER TABLE user_scores ADD COLUMN q$newQuestionId INT DEFAULT 0";
        mysqli_query($db, $updateUserScoresQuery);
        // Set success message
        $successMessage = "Question added successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Quiz Game - Add Question</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('../images/photo/back.jpg');
            margin: 0;
            padding: 0;
        }

        .quiz-box {
            max-width: 600px;
            margin: 50px auto;
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        textarea,
        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        .success-message {
            color: #4caf50;
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="quiz-box">
        <div class="title">Brain Bowl - Add Question</div>

        <!-- Display success message if set -->
        <?php if (!empty($successMessage)) : ?>
            <p class="success-message"><?= $successMessage; ?></p>
        <?php endif; ?>

        <form method="post" action="">
            <div class="form-group">
                <label for="newQuestion">New Question:</label>
                <textarea name="newQuestion" required></textarea>
            </div>
            <div class="form-group">
                <label for="newAnswer">Answer to the New Question:</label>
                <input type="text" name="newAnswer" required>
            </div>
            <div class="form-group">
                <label>Options:</label>
                <?php
                for ($i = 1; $i <= 4; $i++) {
                    echo '<input type="text" name="option' . $i . '" placeholder="Option ' . $i . '" required>';
                }
                ?>
            </div>
            <div class="form-group">
                <label for="correctOption">Correct Option:</label>
                <select name="correctOption" required>
                    <?php
                    for ($i = 1; $i <= 4; $i++) {
                        echo '<option value="' . $i . '">Option ' . $i . '</option>';
                    }
                    ?>
                </select>
            </div>
            <button type="button" onclick="window.location.href='adminindexdash.php';">Exit</button>
            <button type="submit" name="addQuestion">Add Question</button>
        </form>
    </div>
</body>

</html>
