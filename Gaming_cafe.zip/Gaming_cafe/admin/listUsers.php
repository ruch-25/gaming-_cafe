<!DOCTYPE html>
<html lang="en">
<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

// Check if the user has just been deleted
if (isset($_GET['delete_status']) && $_GET['delete_status'] == 'success') {
    echo '<script>alert("User deleted successfully.");</script>';
}

// Check if a new user is added successfully
if (isset($_GET['add_status']) && $_GET['add_status'] == 'success') {
    $success = '<div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    New User Added Successfully.
                </div>';
    echo '<script>alert("New User Added Successfully!");</script>';
}

// Initialize variables for search
$searched = false;
$searchUsername = '';

// Check if a search is performed
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searched = true;
    $searchUsername = $_GET['search'];
}

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>All Users</title>
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/helper.css" rel="stylesheet">

    <style>
        /* Reset some default styles for body */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

/* Set background image for the entire page */
body {
    background-image: url('../images/photo/back.jpg');
}

/* Style for the header */
.header {
    background-color: #fff; /* Set your desired background color */
}

/* Style for the navbar */
.navbar {
    background-color: #333; /* Set your desired background color */
    color: #fff; /* Set text color */
}

/* Style for the page wrapper */
#main-wrapper {
    display: flex;
    flex-direction: column;
    min-height: 100vh; /* Make sure the wrapper takes at least the full viewport height */
}

/* Style for the container */
.container-fluid {
    padding: 20px;
}

/* Style for the table */
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

/* Style for table headings */
thead th {
    background-color: #343a40; /* Set your desired background color */
    color: #fff; /* Set text color */
}

/* Style for table rows */
tbody td {
    background-color: #f8f9fa; /* Set your desired background color */
}

/* Style for the delete button */
.btn-danger {
    background-color: #dc3545; /* Set your desired background color */
    color: #fff; /* Set text color */
}

/* Style for the footer */
footer {
    background-color: #333; /* Set your desired background color */
    color: #fff; /* Set text color */
    padding: 10px 0;
    text-align: center;
}

/* Style for the scripts section */
script {
    /* Add any specific styles for scripts if needed */
}

        </style>

    <script>
        function confirmDelete(username) {
            var confirmation = confirm("Are you sure you want to delete the user '" + username + "'?");
            if (confirmation) {
                window.location.href = "delete_user.php?res_del=" + username;
            }
        }
    </script>
</head>

<body>
    <div style="background-image: url('../images/photo/back.jpg');">
        <div id="main-wrapper">
            <!-- (Your existing HTML content) -->
            <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="col-lg-12">
                                <div class="card card-outline-primary">
                                    <div class="card-header">
                                        <h4 class="m-b-0 text-white">All Users</h4>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!-- Search Bar -->
                                            <form class="form-inline">
                                                <input class="form-control mr-sm-2" type="search" placeholder="Search by username" aria-label="Search" id="searchInput" value="<?php echo $searchUsername; ?>">
                                                <button class="btn btn-outline-success my-2 my-sm-0" type="button" onclick="searchUser()">Search</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="table-responsive m-t-40">
                                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Registration Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($searched) {
                                                    // If a search is performed, only display matching results
                                                    $sql = "SELECT * FROM userregistration WHERE username LIKE '%$searchUsername%'";
                                                } else {
                                                    // If no search is performed, display all users
                                                    $sql = "SELECT * FROM userregistration";
                                                }

                                                $query = mysqli_query($db, $sql);

                                                if (!mysqli_num_rows($query) > 0) {
                                                    echo '<td colspan="4"><center>No Users</center></td>';
                                                } else {
                                                    while ($rows = mysqli_fetch_array($query)) {
                                                        echo '<tr>
                                                                <td>' . $rows['username'] . '</td>
                                                                <td>' . $rows['email'] . '</td>
                                                                <td>' . $rows['registation_date'] . '</td>
                                                                <td>
                                                                    <a href="javascript:void(0);" onclick="confirmDelete(\'' . $rows['username'] . '\')" class="btn btn-danger btn-flat btn-addon btn-xs m-b-10">
                                                                        <i class="fa fa-trash-o" style="font-size:16px"></i>
                                                                    </a> 
                                                                </td>
                                                              </tr>';
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button class="btn btn-secondary" onclick="window.location.href='adminindexdash.php'">Back</button>
        <?php include "include/footer.php" ?>
    </div>

    <!-- Display the success message if set -->
    <?php if (isset($success)) echo $success; ?>

    <script>
        // Function to search users by username
        function searchUser() {
            var username = document.getElementById('searchInput').value.trim();
            window.location.href = "listUsers.php?search=" + username;
        }

        // Function to show confirmation modal
        function confirmDelete(username) {
            var confirmation = confirm("Are you sure you want to delete the user '" + username + "'?");
            if (confirmation) {
                window.location.href = "delete_user.php?res_del=" + username;
            }
        }
    </script>
</body>
</html>
